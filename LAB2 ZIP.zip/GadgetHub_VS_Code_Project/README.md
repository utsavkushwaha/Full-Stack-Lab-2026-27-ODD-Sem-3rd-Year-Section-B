# GadgetHub — Lab Experiment 02

**Experiment:** Making It Interactive (Vanilla JavaScript)  
**Subject:** Full Stack Development

## Features
- Dynamic product cards for 8 gadgets
- Add to cart and persistent cart using `localStorage`
- Cart badge across pages
- Quantity updates, item removal, and live grand total
- Checkout form validation for name, address, city, 6-digit pincode, and 10-digit phone number
- Responsive layout

## Run in Visual Studio Code
1. Extract the ZIP folder.
2. Open the `gadgethub_vscode` folder in VS Code (`File → Open Folder`).
3. Open `index.html` in a browser, or use the **Live Server** extension and click **Go Live**.
4. Navigate to **Products**, add items to the cart, and try the cart and checkout pages.

No Node.js installation is required. Product placeholder images require an internet connection.

## Files
- `index.html` — home page
- `products.html` — product catalogue
- `cart.html` — shopping cart
- `checkout.html` — checkout form
- `style.css` — styling
- `script.js` — interactivity
