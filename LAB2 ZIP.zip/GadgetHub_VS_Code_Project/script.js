// GadgetHub - Lab Experiment 02: Making It Interactive (Vanilla JavaScript)

const products = [
  { id: 1, name: "Wireless Earbuds Pro", price: 2499, image: "https://placehold.co/600x400/f1f5f9/334155?text=Wireless+Earbuds" },
  { id: 2, name: "Smart Watch X5", price: 4999, image: "https://placehold.co/600x400/f1f5f9/334155?text=Smart+Watch" },
  { id: 3, name: "Portable Bluetooth Speaker", price: 1799, image: "https://placehold.co/600x400/f1f5f9/334155?text=Bluetooth+Speaker" },
  { id: 4, name: "20000mAh Power Bank", price: 1299, image: "https://placehold.co/600x400/f1f5f9/334155?text=Power+Bank" },
  { id: 5, name: "7-in-1 USB-C Hub", price: 2199, image: "https://placehold.co/600x400/f1f5f9/334155?text=USB-C+Hub" },
  { id: 6, name: "Ergonomic Wireless Mouse", price: 899, image: "https://placehold.co/600x400/f1f5f9/334155?text=Wireless+Mouse" },
  { id: 7, name: "Aluminum Laptop Stand", price: 1499, image: "https://placehold.co/600x400/f1f5f9/334155?text=Laptop+Stand" },
  { id: 8, name: "RGB Mechanical Keyboard", price: 3499, image: "https://placehold.co/600x400/f1f5f9/334155?text=Mechanical+Keyboard" }
];

function getCart() {
  try { return JSON.parse(localStorage.getItem("cart")) || []; }
  catch { return []; }
}

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartBadge();
}

function updateCartBadge() {
  const count = getCart().reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  document.querySelectorAll("#cart-count, .cart-count").forEach(badge => {
    badge.textContent = count;
    badge.style.display = count > 0 ? "inline-block" : "none";
  });
}

function addToCart(productId) {
  const product = products.find(p => p.id === Number(productId));
  if (!product) return;
  const cart = getCart();
  const existing = cart.find(item => item.id === product.id);
  if (existing) existing.quantity += 1;
  else cart.push({ ...product, quantity: 1 });
  saveCart(cart);
  alert(`"${product.name}" added to cart!`);
}

function renderProducts() {
  const container = document.getElementById("product-list");
  if (!container) return;
  container.innerHTML = products.map(p => `
    <article class="product-card">
      <img src="${p.image}" alt="${p.name}" loading="lazy">
      <div class="card-body">
        <h3>${p.name}</h3>
        <p class="price">₹${p.price.toLocaleString("en-IN")}</p>
        <button class="btn" type="button" onclick="addToCart(${p.id})">Add to Cart</button>
      </div>
    </article>
  `).join("");
}

function calculateTotal() {
  const total = getCart().reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totalEl = document.getElementById("grand-total");
  if (totalEl) totalEl.textContent = "₹" + total.toLocaleString("en-IN");
  return total;
}

function updateQuantity(productId, newQty) {
  const cart = getCart();
  const item = cart.find(i => i.id === Number(productId));
  if (!item) return;
  const parsed = Number.parseInt(newQty, 10);
  item.quantity = Number.isFinite(parsed) && parsed >= 1 ? parsed : 1;
  saveCart(cart);
  renderCart();
}

function removeFromCart(productId) {
  saveCart(getCart().filter(item => item.id !== Number(productId)));
  renderCart();
}

function renderCart() {
  const tbody = document.getElementById("cart-body");
  if (!tbody) return;
  const cart = getCart();
  if (cart.length === 0) {
    tbody.innerHTML = '<tr><td class="empty-cart" colspan="5">Your cart is empty. <a href="products.html">Browse products</a>.</td></tr>';
    calculateTotal();
    return;
  }
  tbody.innerHTML = cart.map(item => `
    <tr>
      <td>${item.name}</td>
      <td><input type="number" min="1" step="1" value="${item.quantity}" aria-label="Quantity for ${item.name}" onchange="updateQuantity(${item.id}, this.value)"></td>
      <td>₹${item.price.toLocaleString("en-IN")}</td>
      <td>₹${(item.price * item.quantity).toLocaleString("en-IN")}</td>
      <td><button class="btn" type="button" style="padding:7px 10px;background:#d93025" onclick="removeFromCart(${item.id})">Remove</button></td>
    </tr>
  `).join("");
  calculateTotal();
}

function validateCheckout(event) {
  event.preventDefault();
  document.querySelectorAll(".error-msg").forEach(el => el.textContent = "");
  const fields = {
    name: document.getElementById("name").value.trim(),
    address: document.getElementById("address").value.trim(),
    city: document.getElementById("city").value.trim(),
    pincode: document.getElementById("pincode").value.trim(),
    phone: document.getElementById("phone").value.trim()
  };
  let valid = true;
  if (!fields.name) { document.getElementById("err-name").textContent = "Name is required."; valid = false; }
  if (!fields.address) { document.getElementById("err-address").textContent = "Address is required."; valid = false; }
  if (!fields.city) { document.getElementById("err-city").textContent = "City is required."; valid = false; }
  if (!/^\d{6}$/.test(fields.pincode)) { document.getElementById("err-pincode").textContent = "Pincode must be exactly 6 digits."; valid = false; }
  if (!/^\d{10}$/.test(fields.phone)) { document.getElementById("err-phone").textContent = "Phone must be exactly 10 digits."; valid = false; }
  if (!valid) return;

  localStorage.removeItem("cart");
  updateCartBadge();
  const form = document.getElementById("checkout-form");
  const msg = document.getElementById("success-msg");
  form.style.display = "none";
  msg.style.display = "block";
  msg.textContent = "Order placed successfully! Thank you for shopping with GadgetHub.";
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  renderProducts();
  renderCart();
  const form = document.getElementById("checkout-form");
  if (form) form.addEventListener("submit", validateCheckout);
});
