# MiniMart Frontend — Lab Sheet 1

A responsive HTML, CSS and JavaScript mini e-commerce frontend based on the uploaded Full Stack Development Lab Sheet 1.

## Pages
- `index.html` — home page with hero banner and featured products
- `products.html` — 8 product cards
- `product-detail.html?id=1` — product detail and quantity selector
- `cart.html` — cart, quantity update, remove item and grand total
- `checkout.html` — delivery form, payment options and demo order confirmation
- `style.css` — shared responsive styling
- `app.js` — product data and cart/checkout logic

## Run in VS Code
1. Extract the ZIP.
2. Open the `MiniMart-frontend` folder in VS Code.
3. Install the **Live Server** extension (if not installed).
4. Right-click `index.html` → **Open with Live Server**.
5. Browse the Products page and test Add to Cart → Cart → Checkout.

You can also open `index.html` directly in a browser, but Live Server is recommended.

## Important
- This is a frontend lab/demo project; it has no backend or real payment processing.
- Cart data is saved in browser `localStorage`.
- The checkout confirmation is simulated locally.
- Replace `YOUR_EMAIL_HERE` in the HTML footer/comments with your own email before submission.
- Product illustrations are emoji-based, so the project does not require downloading images or installing npm packages.
