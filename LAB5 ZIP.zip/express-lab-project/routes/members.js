const express = require("express");
const router = express.Router();

let members = [
  { id: 1, name: "Demo Member One", email: "member1@example.com" },
  { id: 2, name: "Demo Member Two", email: "member2@example.com" }
];
let nextId = 3;

router.get("/", (req, res) => res.json(members));
router.get("/:id", (req, res, next) => {
  const member = members.find((item) => item.id === Number.parseInt(req.params.id, 10));
  if (!member) {
    const err = new Error("Member not found");
    err.status = 404;
    return next(err);
  }
  res.json(member);
});
router.post("/", (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) return res.status(400).json({ error: "name and email are required" });
  const member = { id: nextId++, name, email };
  members.push(member);
  res.status(201).json(member);
});
router.put("/:id", (req, res, next) => {
  const idx = members.findIndex((item) => item.id === Number.parseInt(req.params.id, 10));
  if (idx === -1) {
    const err = new Error("Member not found");
    err.status = 404;
    return next(err);
  }
  members[idx] = { ...members[idx], ...req.body, id: members[idx].id };
  res.json(members[idx]);
});
router.delete("/:id", (req, res, next) => {
  const idx = members.findIndex((item) => item.id === Number.parseInt(req.params.id, 10));
  if (idx === -1) {
    const err = new Error("Member not found");
    err.status = 404;
    return next(err);
  }
  const [removed] = members.splice(idx, 1);
  res.json({ message: "Member deleted", member: removed });
});

module.exports = router;
