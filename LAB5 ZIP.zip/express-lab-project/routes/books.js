const express = require("express");
const router = express.Router();

let books = [
  { id: 1, title: "Clean Code", author: "Robert C. Martin" },
  { id: 2, title: "You Don't Know JS", author: "Kyle Simpson" },
  { id: 3, title: "Eloquent JavaScript", author: "Marijn Haverbeke" }
];
let nextId = 4;

router.get("/", (req, res) => res.json(books));
router.get("/:id", (req, res, next) => {
  const book = books.find((item) => item.id === Number.parseInt(req.params.id, 10));
  if (!book) {
    const err = new Error("Book not found");
    err.status = 404;
    return next(err);
  }
  res.json(book);
});
router.post("/", (req, res) => {
  const { title, author } = req.body;
  if (!title || !author) return res.status(400).json({ error: "title and author are required" });
  const book = { id: nextId++, title, author };
  books.push(book);
  res.status(201).json(book);
});
router.put("/:id", (req, res, next) => {
  const idx = books.findIndex((item) => item.id === Number.parseInt(req.params.id, 10));
  if (idx === -1) {
    const err = new Error("Book not found");
    err.status = 404;
    return next(err);
  }
  books[idx] = { ...books[idx], ...req.body, id: books[idx].id };
  res.json(books[idx]);
});
router.delete("/:id", (req, res, next) => {
  const idx = books.findIndex((item) => item.id === Number.parseInt(req.params.id, 10));
  if (idx === -1) {
    const err = new Error("Book not found");
    err.status = 404;
    return next(err);
  }
  const [removed] = books.splice(idx, 1);
  res.json({ message: "Book deleted", book: removed });
});

module.exports = router;
