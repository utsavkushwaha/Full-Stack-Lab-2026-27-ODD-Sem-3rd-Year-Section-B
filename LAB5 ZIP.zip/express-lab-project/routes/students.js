const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
  res.json([{ id: 1, name: "Demo Student" }]);
});

router.get("/:id", (req, res) => {
  res.json({ id: req.params.id, message: "Student details" });
});

module.exports = router;
