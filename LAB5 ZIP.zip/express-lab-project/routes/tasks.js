const express = require("express");
const router = express.Router();

let tasks = [
  { id: 1, title: "Learn Express", done: false },
  { id: 2, title: "Build REST API", done: true }
];
let nextId = 3;

router.get("/", (req, res) => res.json(tasks));
router.get("/:id", (req, res, next) => {
  const task = tasks.find((item) => item.id === Number.parseInt(req.params.id, 10));
  if (!task) {
    const err = new Error("Task not found");
    err.status = 404;
    return next(err);
  }
  res.json(task);
});
router.post("/", (req, res) => {
  if (!req.body.title) return res.status(400).json({ error: "title is required" });
  const task = { id: nextId++, title: req.body.title, done: false };
  tasks.push(task);
  res.status(201).json(task);
});
router.put("/:id", (req, res, next) => {
  const idx = tasks.findIndex((item) => item.id === Number.parseInt(req.params.id, 10));
  if (idx === -1) {
    const err = new Error("Task not found");
    err.status = 404;
    return next(err);
  }
  tasks[idx] = { ...tasks[idx], ...req.body, id: tasks[idx].id };
  res.json(tasks[idx]);
});
router.delete("/:id", (req, res, next) => {
  const idx = tasks.findIndex((item) => item.id === Number.parseInt(req.params.id, 10));
  if (idx === -1) {
    const err = new Error("Task not found");
    err.status = 404;
    return next(err);
  }
  const [removed] = tasks.splice(idx, 1);
  res.json({ message: "Task deleted", task: removed });
});

module.exports = router;
