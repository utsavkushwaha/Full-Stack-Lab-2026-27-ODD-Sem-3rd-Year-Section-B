require("dotenv").config();
const express = require("express");
const path = require("path");

const studentsRouter = require("./routes/students");
const booksRouter = require("./routes/books");
const tasksRouter = require("./routes/tasks");
const membersRouter = require("./routes/members");

const app = express();
const PORT = process.env.PORT || 4000;

// Global request logger middleware
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// Parse JSON and HTML form bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static assets from public/
app.use(express.static(path.join(__dirname, "public")));

// Demo API-key middleware for /admin routes
function apiAuth(req, res, next) {
  if (req.path.startsWith("/admin") && !req.headers["x-api-key"]) {
    return res.status(403).json({ error: "Forbidden – x-api-key header required" });
  }
  next();
}
app.use(apiAuth);

// Part A: Basic server
app.get("/", (req, res) => res.send("Express Lab Running"));

// Part B: Basic routes
app.get("/about", (req, res) => {
  res.json({ name: "Student Name", rollNo: "Enter your roll number" });
});
app.get("/courses", (req, res) => {
  res.json(["Full Stack Web Development", "Data Structures", "Database Management"]);
});
app.post("/echo", (req, res) => res.json(req.body));

// Part C: Route parameters and query strings
app.get("/students/:id", (req, res) => {
  res.json({ id: req.params.id, message: "Student details" });
});
app.get("/search", (req, res) => {
  res.json({ name: req.query.name, age: req.query.age });
});
app.get("/products/:category/:id", (req, res) => {
  res.json({ category: req.params.category, id: req.params.id });
});

// Part D: Route-specific middleware
function requireApiKey(req, res, next) {
  if (!req.headers["x-api-key"]) {
    return res.status(403).json({ error: "Forbidden – x-api-key header required" });
  }
  next();
}
app.get("/admin/dashboard", requireApiKey, (req, res) => {
  res.json({ message: "Welcome to Admin Dashboard", secret: "admin-data" });
});

// Part E: JSON and form body handling
app.post("/register", (req, res) => {
  const { name, email } = req.body;
  res.json({ message: `Registration successful for ${name || "user"}`, email });
});
app.post("/contact", (req, res) => {
  console.log("Contact form:", req.body);
  res.send("Thank you for contacting us!");
});

// Parts F, G and J: Modular routers and CRUD APIs
app.use("/api/students", studentsRouter);
app.use("/api/books", booksRouter);
app.use("/api/tasks", tasksRouter);
app.use("/api/members", membersRouter);

// 404 handler (must be after all valid routes)
app.use((req, res) => res.status(404).json({ error: "Route not found" }));

// Centralized error handler (four parameters are required)
app.use((err, req, res, next) => {
  console.error("Error:", err.message);
  res.status(err.status || 500).json({ error: err.message || "Internal Server Error" });
});

app.listen(PORT, () => {
  console.log(`Express Lab server running on http://localhost:${PORT}`);
});
