# Express.js Lab – Experiment 05

A runnable Node.js + Express project covering routing, route parameters, query strings, middleware, JSON/form parsing, modular routers, REST CRUD APIs, static files, dotenv configuration, 404 handling, and centralized error handling.

## Requirements
- Node.js and npm
- VS Code (recommended)
- Postman or Thunder Client for testing POST/PUT/DELETE endpoints

## Run the project
1. Extract the ZIP and open the `express-lab-project` folder in VS Code.
2. Open the VS Code terminal in this folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the server:
   ```bash
   npm start
   ```
   Or use auto-restart during development:
   ```bash
   npm run dev
   ```
5. Open http://localhost:4000 in your browser.

Change `PORT` in `.env` if port 4000 is already in use. Keep `.env` private if you add real secrets; the included API key is only a lab demonstration.

## Main endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | Basic server response |
| GET | `/about` | About response |
| GET | `/courses` | List courses |
| POST | `/echo` | Return the submitted JSON body |
| GET | `/students/5` | Route parameter example |
| GET | `/search?name=Utsav&age=21` | Query-string example |
| GET | `/products/electronics/42` | Multiple route parameters |
| GET | `/admin/dashboard` | Requires `x-api-key` header |
| POST | `/register` | JSON registration example |
| POST | `/contact` | Form/body parsing example |
| GET/POST | `/api/books` | List or create books |
| GET/PUT/DELETE | `/api/books/:id` | Read, update, or delete one book |
| GET/POST | `/api/tasks` | List or create tasks |
| GET/PUT/DELETE | `/api/tasks/:id` | Read, update, or delete one task |
| GET/POST | `/api/members` | List or create members |
| GET/PUT/DELETE | `/api/members/:id` | Read, update, or delete one member |
| GET | `/api/students/:id` | Modular student route |

## Test examples

For `POST /api/books`, select **Body → raw → JSON** in Postman and send:
```json
{
  "title": "Node Design Patterns",
  "author": "Mario"
}
```

For `GET /admin/dashboard`, add this request header:
- Key: `x-api-key`
- Value: `secret123`

The CRUD data is stored in memory, so it resets when the server restarts. This is intended for a lab exercise, not production use.
