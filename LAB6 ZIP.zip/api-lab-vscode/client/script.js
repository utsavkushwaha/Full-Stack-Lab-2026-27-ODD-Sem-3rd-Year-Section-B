const API_URL = "http://localhost:5000/api/tasks";
const statusEl = document.getElementById("status");
const errorEl = document.getElementById("error");
const listEl = document.getElementById("list");

async function loadTasks() {
  statusEl.textContent = "Loading...";
  errorEl.textContent = "";
  listEl.replaceChildren();

  try {
    const res = await fetch(API_URL);
    if (!res.ok) throw new Error(`Server error: ${res.status} ${res.statusText}`);
    const tasks = await res.json();
    statusEl.textContent = `${tasks.length} task(s) loaded`;
    tasks.forEach(task => {
      const li = document.createElement("li");
      li.textContent = `${task.title} ${task.completed ? "✓ Completed" : "— Pending"}`;
      listEl.appendChild(li);
    });
  } catch (err) {
    statusEl.textContent = "";
    errorEl.textContent = "Failed to load tasks. Is the API server running? " + err.message;
  }
}

document.getElementById("reload").addEventListener("click", loadTasks);
loadTasks();
