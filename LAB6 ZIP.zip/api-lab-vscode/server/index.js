require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 5000;
const API_KEY = process.env.API_KEY || "lab-secret-key-123";

let tasks = [
  { id: 1, title: "Learn Express routing", completed: true },
  { id: 2, title: "Build REST CRUD API", completed: false },
  { id: 3, title: "Add CORS and middleware", completed: false },
  { id: 4, title: "Connect React client", completed: false },
  { id: 5, title: "Test with Postman", completed: true }
];
let nextId = 6;

app.use(cors());
app.use(express.json());

app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

function requireApiKey(req, res, next) {
  const key = req.headers["x-api-key"];
  if (!key || key !== API_KEY) {
    return res.status(401).json({
      error: "Unauthorized — valid x-api-key header required"
    });
  }
  next();
}

app.get("/api/tasks", (req, res) => res.json(tasks));

app.get("/api/tasks/:id", (req, res) => {
  const task = tasks.find(t => t.id === Number.parseInt(req.params.id, 10));
  if (!task) return res.status(404).json({ error: "Task not found" });
  res.json(task);
});

app.post("/api/tasks", requireApiKey, (req, res) => {
  const { title, completed } = req.body;
  if (typeof title !== "string" || !title.trim()) {
    return res.status(400).json({ error: "title is required" });
  }
  const task = {
    id: nextId++,
    title: title.trim(),
    completed: Boolean(completed)
  };
  tasks.push(task);
  res.status(201).json(task);
});

app.put("/api/tasks/:id", requireApiKey, (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  const idx = tasks.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "Task not found" });

  const { title, completed } = req.body;
  if (title !== undefined) {
    if (typeof title !== "string" || !title.trim()) {
      return res.status(400).json({ error: "title must be a non-empty string" });
    }
    tasks[idx].title = title.trim();
  }
  if (completed !== undefined) tasks[idx].completed = Boolean(completed);
  res.json(tasks[idx]);
});

app.delete("/api/tasks/:id", requireApiKey, (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  const idx = tasks.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "Task not found" });
  const removed = tasks.splice(idx, 1)[0];
  res.json({ message: "Task deleted", task: removed });
});

app.use((req, res) => res.status(404).json({ error: "Route not found" }));

app.use((err, req, res, next) => {
  console.error("Error:", err.message);
  res.status(err.status || 500).json({
    error: err.message || "Internal Server Error"
  });
});

app.listen(PORT, () => {
  console.log(`API Lab server running at http://localhost:${PORT}`);
  console.log(`API key for POST/PUT/DELETE: ${API_KEY}`);
});
