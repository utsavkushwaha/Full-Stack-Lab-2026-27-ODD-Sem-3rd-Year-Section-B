import { useEffect, useState } from "react";
import axios from "axios";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000";
const API_KEY = "lab-secret-key-123"; // Lab demo only; never expose real secrets in frontend code.

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [title, setTitle] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function loadTasks() {
    setLoading(true);
    setError("");
    try {
      const { data } = await axios.get(`${API_BASE}/api/tasks`);
      setTasks(data);
    } catch (err) {
      setError(err.response?.data?.error || err.message || "Failed to load tasks");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadTasks(); }, []);

  async function handleAdd(event) {
    event.preventDefault();
    if (!title.trim()) return;
    setSubmitting(true);
    setError("");
    try {
      const { data } = await axios.post(
        `${API_BASE}/api/tasks`,
        { title: title.trim(), completed: false },
        { headers: { "x-api-key": API_KEY } }
      );
      setTasks(previous => [...previous, data]);
      setTitle("");
    } catch (err) {
      setError(err.response?.data?.error || err.message || "Could not add task");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id) {
    setError("");
    try {
      await axios.delete(`${API_BASE}/api/tasks/${id}`, {
        headers: { "x-api-key": API_KEY }
      });
      setTasks(previous => previous.filter(task => task.id !== id));
    } catch (err) {
      setError(err.response?.data?.error || err.message || "Could not delete task");
    }
  }

  return (
    <main className="shell">
      <section className="panel">
        <div className="eyebrow">FULL STACK WEB DEVELOPMENT · LAB 06</div>
        <h1>Task Manager</h1>
        <p className="subtitle">React client connected to your Express REST API.</p>

        <form className="add-form" onSubmit={handleAdd}>
          <input
            value={title}
            onChange={event => setTitle(event.target.value)}
            placeholder="Enter a new task..."
            aria-label="New task title"
            disabled={submitting}
          />
          <button type="submit" disabled={submitting || !title.trim()}>
            {submitting ? "Adding..." : "Add task"}
          </button>
        </form>

        {error && <div className="error" role="alert">{error}</div>}
        {loading ? <p className="status">Loading tasks...</p> : (
          <>
            <div className="list-heading">
              <h2>Your tasks</h2><span>{tasks.length} total</span>
            </div>
            {tasks.length === 0 ? <p className="status">No tasks yet. Add your first one.</p> : (
              <ul className="task-list">
                {tasks.map(task => (
                  <li key={task.id}>
                    <div>
                      <span className={`dot ${task.completed ? "complete" : ""}`} />
                      <span className={task.completed ? "done" : ""}>{task.title}</span>
                      <small>{task.completed ? "Completed" : "Pending"}</small>
                    </div>
                    <button className="delete" type="button" onClick={() => handleDelete(task.id)}>Delete</button>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
        <button className="reload" type="button" onClick={loadTasks} disabled={loading}>Reload tasks</button>
      </section>
      <footer>Node.js · Express · REST API · React · Axios</footer>
    </main>
  );
}
