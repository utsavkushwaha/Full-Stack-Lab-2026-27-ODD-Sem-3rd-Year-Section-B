# Lab Sheet 6 — API Lab (VS Code)

This project contains:
- Express REST API with in-memory task CRUD, logger, API-key checks, CORS and error handling
- Plain JavaScript client
- React + Vite client

## Requirements
Install Node.js LTS first: https://nodejs.org/

## 1. Start the API server
Open this project folder in VS Code. Open Terminal → New Terminal, then:

```bash
cd server
npm install
npm run dev
```

API runs at http://localhost:5000

## 2. Run the plain JavaScript client
Keep the server terminal running. Open a **second terminal**:

```bash
cd client
npx --yes http-server -p 5500
```

Open http://localhost:5500

## 3. Run the React client
Keep the server running. Open a **third terminal**:

```bash
cd client-react
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

## API endpoints
- `GET /api/tasks` — list all tasks
- `GET /api/tasks/:id` — get one task
- `POST /api/tasks` — create (requires `x-api-key`)
- `PUT /api/tasks/:id` — update (requires `x-api-key`)
- `DELETE /api/tasks/:id` — delete (requires `x-api-key`)

Demo API key: `lab-secret-key-123`

**Note:** Data is stored in memory, so tasks reset when the server restarts. The demo key is for this lab only, not production use.
