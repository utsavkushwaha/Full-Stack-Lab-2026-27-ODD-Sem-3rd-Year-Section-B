# Lab Sheet 7 — SQL in VS Code

This folder contains the complete SQL script for the uploaded Lab Experiment 07.

## What you need
- MySQL Server (or MariaDB)
- VS Code
- A MySQL extension for VS Code, or MySQL Workbench

## Run it in VS Code
1. Install and start MySQL Server.
2. In VS Code, install a MySQL extension and connect to `localhost` with your MySQL username/password.
3. Open `sql/lab7_all_queries.sql`.
4. Execute the script using your extension's Run/Execute SQL command.

Alternative: open MySQL Workbench, connect to your local server, open this `.sql` file, and click the lightning-bolt Execute button.

## Important
- This script is written for MySQL 8+ / MariaDB.
- It starts with `DROP DATABASE IF EXISTS college_db;`, so running it again deletes and recreates the lab database.
- Run the whole script to execute all Parts A–H. Some VS Code SQL extensions execute only the selected query; check your extension's behavior.
- The intentionally invalid age-15 insert is commented out so the rest of the script can run. Uncomment it and execute separately to observe the CHECK constraint error.
- The sample data is restored whenever the script is run from the beginning.
